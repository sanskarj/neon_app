from django.contrib import admin
from .models import experience
# Register your models here.
admin.site.register(experience)
