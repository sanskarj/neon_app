from django.apps import AppConfig


class NeonappConfig(AppConfig):
    name = 'neonapp'
